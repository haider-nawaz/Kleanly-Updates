# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Kleanly is a macOS utility app that allows users to temporarily disable keyboard/trackpad input for cleaning purposes. The app uses SwiftUI and integrates with Mixpanel for analytics.

## Build Commands

This is an Xcode project for macOS. To build and run:

- **Build**: Use Xcode IDE or `xcodebuild` command line tools
- **Run**: Use Xcode's run button (Cmd+R) or build the project and run the generated .app
- **Test**: No specific test suite found - use Xcode's test navigator if tests exist

## Architecture Overview

### Core Components

- **kleanlyApp.swift**: Main app entry point with minimal SwiftUI scene
- **AppDelegate** (in ContentView.swift): Primary application logic handling menu bar, popover, and app lifecycle
- **KeyboardController**: Manages keyboard/trackpad input blocking via CGEvent taps
- **CleaningManager**: Singleton class managing cleaning sessions and analytics
- **OverlayWindow**: Custom NSWindow subclass for cleaning mode dark overlay
- **AnalyticsService**: Thin wrapper around Mixpanel SDK — all analytics calls go through this file

### UI Structure

- **ContentView**: Main popover view with settings and quit buttons
- **SettingsView**: Settings window with cleaning options and preferences
- **Apps/**: Directory containing app discovery and display components
  - **AppListViewModel**: Handles loading app data from remote URLs (with loading/error states)
  - **AppItemView, AppInfo, PlatformChip, etc.**: UI components for app listing

### Key Features

1. **Menu Bar Integration**: Animated menu bar icon with click handlers
2. **Cleaning Modes**: Supports both trackpad and screen cleaning with visual feedback
3. **Settings**: Transparency control, hide menu bar option, component toggles
4. **Mixpanel Analytics**: Event tracking via AnalyticsService wrapper
5. **Toast Notifications**: User feedback system via ToastViewController

### Data Persistence

Uses `@AppStorage` and `UserDefaults` for:
- User preferences (cleanTrackpad, cleanScreen, transparency, hideMenubarIcon)
- Usage statistics (clean counts, total time)
- User identification (persistent UUID)

### Dependencies (Swift Package Manager)

- Mixpanel Swift SDK (`mixpanel-swift`)

### App Behavior

- **Dual Mode**: Can run with or without menu bar icon
- **Auto-launch**: When menu bar hidden, starts cleaning mode automatically
- **Animation**: Menu bar icon animates during cleaning sessions
- **Restart Logic**: Built-in app restart functionality for settings changes

## File Organization

- Root level: Core app files and main views
- `Apps/`: App discovery and listing functionality
- `Assets.xcassets/`: Images including animated broom icons
- `Preview Content/`: Xcode preview assets

## Important Notes

- App uses sandboxing with network client and file read permissions
- Integrates with macOS accessibility features for input blocking
- Mixpanel token is configured in AnalyticsService.swift
- No traditional test framework setup found
- Logging uses os.Logger (subsystem: com.haiderdev.kleanly) — debug logs wrapped in `#if DEBUG`
